// let toDoList = []
// const toDoForm = document.getElementById('toDoForm')

document.addEventListener('alpine:init', () => {
    Alpine.store('toDoList', {
        data: [],
    })
})

function toDoList() {
    return {
        toDoList: [],
        newTodo: {
            title: '',
            description: '',
            duration: '',
            deadline: '',
            tags: '',
        },
        createToDoObject(form) {
            let formFields = new FormData(form)
            toDoList = [
                ...toDoList,
                {
                    endPrevision: new Date(),
                    id: new Date().valueOf().toString(36),
                    isDone: false,
                    ...Object.fromEntries(formFields),
                },
            ]
        },
    }
}
// toDoForm.addEventListener('submit', (e) => {
//     e.preventDefault()
//     createToDoObject(e.target)
//     toDoForm.reset()
//     Alpine.store('toDoList').data = toDoList
//     console.log(Alpine.store('toDoList').data)
// })
